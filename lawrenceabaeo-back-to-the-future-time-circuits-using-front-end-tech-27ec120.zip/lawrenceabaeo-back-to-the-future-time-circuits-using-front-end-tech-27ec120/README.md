# back-to-the-future-time-circuits-using-front-end-tech
A front end project that copies the 'Time Circuits' console seen in the movie 'Back To The Future'

* See it working here: [http://lawrenceabaeo.github.io/back-to-the-future-time-circuits-using-front-end-tech/project/index.html](http://lawrenceabaeo.github.io/back-to-the-future-time-circuits-using-front-end-tech/project/index.html)

* Project blog here: [http://lawrenceabaeo.github.io/back-to-the-future-time-circuits-using-front-end-tech/](http://lawrenceabaeo.github.io/back-to-the-future-time-circuits-using-front-end-tech/)
